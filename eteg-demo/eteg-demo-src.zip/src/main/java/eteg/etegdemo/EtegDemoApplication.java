package eteg.etegdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EtegDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(EtegDemoApplication.class, args);
	}
}
